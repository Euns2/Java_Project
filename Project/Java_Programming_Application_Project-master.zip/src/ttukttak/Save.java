package ttukttak;

import javax.swing.*;
import java.awt.*;

public class Save extends JFrame{

	public static void main(String[] args) {

	}

}
